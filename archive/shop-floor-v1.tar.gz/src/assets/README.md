# Original procedural assets

Machine artwork lives in `components/MachineArt.tsx`. Animated stock, chips, coolant, and tool paths live in `components/StockCanvas.tsx`. All artwork is original SVG or Canvas, with no third-party photos, trademarks, or copied control screens.

Future licensed replacements can be stored here, grouped into `machines/`, `materials/`, and `audio/`. Keep the procedural fallback and descriptive accessible text when replacing assets.
