import { Component, StrictMode } from "react";
import type { ErrorInfo, ReactNode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles.css";
class ErrorBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Shop Floor could not render", error, info.componentStack);
  }
  render() {
    return this.state.failed ? (
      <div className="error-screen">
        <h1>The shop needs a moment.</h1>
        <p>
          Your completed features are saved locally. Reload to reopen the floor.
        </p>
        <button
          className="button primary"
          title="Reload the application and restore your saved progress"
          onClick={() => window.location.reload()}
        >
          Reopen the shop
        </button>
      </div>
    ) : (
      this.props.children
    );
  }
}
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
