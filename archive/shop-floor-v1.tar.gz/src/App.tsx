import { useState } from "react";
import {
  ArrowRight,
  Box,
  ChevronRight,
  CircleHelp,
  ClipboardCheck,
  Factory,
  FlaskConical,
  LayoutGrid,
  PanelTop,
  RotateCcw,
  ShieldCheck,
} from "lucide-react";
import { useGame } from "./hooks/useGame";
import type { Station as StationType } from "./domain/types";
import { Home } from "./components/Home";
import { Station } from "./components/Station";
import { Traveler } from "./components/Traveler";
import { Results } from "./components/Results";
import { Button, Modal } from "./components/ui";
import { completedCount, requiredCount, stageReady } from "./domain/game";

export default function App() {
  const job = useGame("job");
  const practice = useGame("practice");
  const [mode, setMode] = useState<"job" | "practice">("job");
  const game = mode === "job" ? job : practice;
  const { state, dispatch } = game;
  const [screen, setScreen] = useState<"home" | "station" | "results">("home");
  const [station, setStation] = useState<StationType>("lathe");
  const [traveler, setTraveler] = useState(false);
  const [sessionVersion, setSessionVersion] = useState(0);
  const [reset, setReset] = useState(false);
  const [about, setAbout] = useState(false);
  const [tutorial, setTutorial] = useState(() => {
    try {
      return localStorage.getItem("shop-floor-guide") !== "dismissed";
    } catch {
      return true;
    }
  });
  const guide = (show: boolean) => {
    setTutorial(show);
    try {
      localStorage.setItem("shop-floor-guide", show ? "active" : "dismissed");
    } catch {
      /* usable without storage */
    }
  };
  const hold = () => {
    if (state.active && !state.paused) dispatch({ type: "hold" });
  };
  const home = () => {
    hold();
    setMode("job");
    setScreen("home");
  };
  const visit = (next: StationType) => {
    hold();
    setMode("job");
    setStation(next);
    setScreen("station");
  };
  const start = () => {
    setMode("job");
    if (job.state.stage === "complete") setScreen("results");
    else {
      setStation(job.state.stage);
      setScreen("station");
    }
  };
  const startPractice = () => {
    hold();
    setMode("practice");
    setStation("mill");
    setScreen(practice.state.stage === "complete" ? "results" : "station");
  };
  const advance = () => {
    if (state.active || state.stage !== station || !stageReady(state, station))
      return;
    dispatch({ type: "advance" });
    if (station === "lathe") {
      setStation("mill");
      setScreen("station");
    } else setScreen("results");
  };
  const replay = () => {
    setSessionVersion((value) => value + 1);
    dispatch({ type: "reset" });
    setStation(mode === "job" ? "lathe" : "mill");
    setScreen("station");
    setReset(false);
  };
  const inspect = () => {
    hold();
    if (state.stage === "complete") setScreen("results");
    else setTraveler(true);
  };
  const help = () => {
    if (screen === "home") {
      start();
      guide(true);
    } else if (screen === "station") guide(!tutorial);
    else setAbout(true);
  };
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button
          className="brand-mark"
          title="Shop Floor — return to the dashboard"
          aria-label="Shop Floor home"
          onClick={home}
        >
          <Logo />
        </button>
        <div className="sidebar-nav">
          <Nav
            icon={<LayoutGrid size={21} />}
            label="Overview"
            active={screen === "home"}
            onClick={home}
          />
          <span className="nav-divider" />
          <Nav
            icon={<Factory size={21} />}
            label="Turning"
            active={screen === "station" && station === "lathe"}
            onClick={() => visit("lathe")}
          />
          <Nav
            icon={<PanelTop size={21} />}
            label="Milling"
            active={screen === "station" && station === "mill"}
            onClick={() => visit("mill")}
          />
          <Nav
            icon={<ClipboardCheck size={21} />}
            label="Inspection"
            active={screen === "results"}
            onClick={inspect}
          />
        </div>
        <div className="sidebar-bottom">
          <Nav
            icon={<CircleHelp size={21} />}
            label="Guide"
            active={false}
            onClick={help}
          />
          <button
            className="avatar"
            title="About this fictional workshop"
            aria-label="About Shop Floor"
            onClick={() => setAbout(true)}
          >
            SF
          </button>
        </div>
      </aside>
      <div className="app-main">
        <header className="topbar">
          <button
            className="wordmark"
            title="Return to the Shop Floor dashboard"
            onClick={home}
          >
            SHOP<span>FLOOR</span>
            <span className="wordmark-period">.</span>
          </button>
          <span className="topbar-divider" />
          <div className="breadcrumb">
            Workspace <ChevronRight size={13} />
            <strong>
              {screen === "home"
                ? "The workshop"
                : screen === "results"
                  ? "Inspection"
                  : station === "lathe"
                    ? "Turning station"
                    : "Milling station"}
            </strong>
          </div>
          <div className="topbar-right">
            <span className="simulation-label">
              <span className="status-dot" /> SIMULATION MODE
            </span>
            <span className="topbar-divider" />
            <span className="shift-label">SHIFT 001</span>
            <button
              className="topbar-help"
              title="About Shop Floor and its fictional game units"
              aria-label="About the simulation"
              onClick={() => setAbout(true)}
            >
              <ShieldCheck size={17} />
            </button>
          </div>
        </header>
        {game.storageError && (
          <div className="storage-notice">
            Local saving is unavailable in this browser. Your session is
            playable, but progress will not survive a reload.
          </div>
        )}
        {mode === "practice" && screen !== "home" && (
          <div className="practice-banner">
            <span>
              <FlaskConical size={15} /> Billet practice · your wheel-hub job is
              saved separately
            </span>
            <Button
              tip="Return to the main job without changing practice progress"
              className="text-button"
              onClick={() => {
                hold();
                start();
              }}
            >
              Return to job <ArrowRight size={14} />
            </Button>
          </div>
        )}
        <main>
          {screen === "home" ? (
            <Home
              state={job.state}
              onStation={visit}
              onStart={start}
              onTraveler={() => setTraveler(true)}
              onTutorial={() => {
                start();
                guide(true);
              }}
              onReset={() => setReset(true)}
              onPractice={startPractice}
            />
          ) : screen === "station" ? (
            <Station
              key={`${mode}-${station}-${sessionVersion}`}
              state={state}
              dispatch={dispatch}
              station={station}
              onBack={home}
              onTraveler={() => setTraveler(true)}
              onAdvance={advance}
              tutorial={tutorial}
              setTutorial={guide}
              onPractice={startPractice}
              onReset={() => {
                hold();
                setReset(true);
              }}
            />
          ) : (
            <Results
              state={state}
              onReplay={replay}
              onBack={home}
              onTraveler={() => setTraveler(true)}
            />
          )}
        </main>
      </div>
      {traveler && (
        <Traveler state={state} onClose={() => setTraveler(false)} />
      )}
      {reset && (
        <Modal
          title="A fresh piece of stock?"
          subtitle="NEW BEGINNINGS"
          onClose={() => setReset(false)}
        >
          <div className="reset-illustration">
            <RotateCcw size={36} />
          </div>
          <p className="modal-note">
            This resets your{" "}
            {mode === "job" ? "wheel-hub job" : "billet practice"}, including{" "}
            {completedCount(state)} of{" "}
            {requiredCount(mode === "practice" ? "mill" : undefined)} accepted
            required features and your current score. You’ll start with a new
            blank.
          </p>
          <div className="modal-actions">
            <Button
              tip="Keep your current part and progress"
              className="subtle"
              onClick={() => setReset(false)}
            >
              Keep working
            </Button>
            <Button
              tip="Discard this session’s progress and begin again"
              className="primary"
              onClick={replay}
            >
              Start fresh <ArrowRight size={16} />
            </Button>
          </div>
        </Modal>
      )}
      {about && (
        <Modal
          title="A little precision. A lot of play."
          subtitle="WELCOME TO SHOP FLOOR"
          onClose={() => setAbout(false)}
        >
          <div className="about-symbol">
            <Box size={44} />
          </div>
          <p className="modal-note">
            Shop Floor is a fictional workshop about shaping a part, solving
            small challenges, and enjoying the process.
          </p>
          <div className="traveler-note">
            <ShieldCheck size={24} />
            <p>
              Entertainment and education only. No machinery connections, real
              toolpaths, G-code, or operational guidance. Every dimension is an
              invented game unit. Machine artwork and branding are original.
            </p>
          </div>
          <p className="modal-note">
            Use the mouse, touch, or keyboard to select controls. Arrow keys
            adjust focused sliders. Every control has a tooltip. Progress saves
            in this browser; leaving a station holds an active cycle.
          </p>
          <Button
            tip="Close this introduction"
            className="primary full"
            onClick={() => setAbout(false)}
          >
            Sounds good <ArrowRight size={16} />
          </Button>
        </Modal>
      )}
    </div>
  );
}
function Nav({
  icon,
  label,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      className={`nav-item ${active ? "active" : ""}`}
      title={
        label === "Guide"
          ? "Open the interactive tutorial"
          : `Open ${label.toLowerCase()}`
      }
      aria-label={label}
      aria-current={active ? "page" : undefined}
      onClick={onClick}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}
function Logo() {
  return (
    <svg viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <path d="M6 7H25V12H12V15H23V25H5V20H17V17H6V7Z" fill="currentColor" />
      <path d="M25 17H28V25H25Z" fill="currentColor" opacity=".4" />
    </svg>
  );
}
