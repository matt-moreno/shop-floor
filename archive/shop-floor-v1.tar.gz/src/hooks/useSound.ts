import { useEffect, useRef } from "react";
export function useSound(enabled: boolean, running: boolean, spindle: number) {
  const audio = useRef<AudioContext | null>(null);
  useEffect(() => {
    if (!enabled || !running) return;
    try {
      const context = audio.current ?? new AudioContext();
      audio.current = context;
      void context.resume().catch(() => {});
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = "triangle";
      oscillator.frequency.value = 65 + spindle * 0.55;
      gain.gain.setValueAtTime(0, context.currentTime);
      gain.gain.linearRampToValueAtTime(0.045, context.currentTime + 0.15);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      return () => {
        oscillator.stop();
        oscillator.disconnect();
        gain.disconnect();
      };
    } catch {
      /* Audio is an optional progressive enhancement. */
    }
  }, [enabled, running, spindle]);
  useEffect(
    () => () => {
      void audio.current?.close().catch(() => {});
    },
    [],
  );
}
