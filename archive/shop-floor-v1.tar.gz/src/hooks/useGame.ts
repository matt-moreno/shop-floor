import { useEffect, useReducer, useState } from "react";
import { gameReducer, restoreGame } from "../domain/game";
export function useGame(mode: "job" | "practice") {
  const key = `shop-floor-v1-${mode}`;
  const [storageError, setStorageError] = useState(false);
  const [state, dispatch] = useReducer(gameReducer, null, () => {
    try {
      return restoreGame(localStorage.getItem(key), mode);
    } catch {
      return restoreGame(null, mode);
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(
        key,
        JSON.stringify({ ...state, active: null, paused: false }),
      );
    } catch {
      setStorageError(true);
    }
  }, [key, state]);
  useEffect(() => {
    if (!state.active || state.paused) return;
    let last = performance.now();
    const timer = window.setInterval(() => {
      const now = performance.now();
      dispatch({ type: "tick", seconds: Math.min(0.1, (now - last) / 1000) });
      last = now;
    }, 40);
    return () => clearInterval(timer);
  }, [!!state.active, state.paused]);
  useEffect(() => {
    const onHide = () => {
      if (document.hidden && state.active && !state.paused)
        dispatch({ type: "hold" });
    };
    document.addEventListener("visibilitychange", onHide);
    return () => document.removeEventListener("visibilitychange", onHide);
  }, [state.active, state.paused]);
  return { state, dispatch, storageError };
}
