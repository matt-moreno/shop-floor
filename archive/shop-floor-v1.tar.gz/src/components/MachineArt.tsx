import { useId } from "react";
import type { Station } from "../domain/types";

/** Original illustrated machine enclosures. No reference photos or branded artwork. */
export function MachineArt({
  station,
  className = "",
}: {
  station: Station;
  className?: string;
}) {
  const uid = useId().replaceAll(":", "");
  const id = (name: string) => `${uid}-${name}`;
  return (
    <svg
      className={`machine-art ${className}`}
      viewBox="0 0 640 390"
      role="img"
      aria-label={
        station === "lathe"
          ? "Original Horizon turning center illustration with an orange enclosure, chuck, and virtual control panel"
          : "Original Vertex vertical mill illustration with enclosed spindle, vise, and tool carousel"
      }
    >
      <defs>
        <linearGradient id={id("body")} x1="0" y1="0" x2="0.8" y2="1">
          <stop stopColor="#d0d3ce" />
          <stop offset=".45" stopColor="#a4aaa6" />
          <stop offset="1" stopColor="#6d7775" />
        </linearGradient>
        <linearGradient id={id("dark")} x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#434e50" />
          <stop offset="1" stopColor="#171e21" />
        </linearGradient>
        <linearGradient id={id("window")} x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#142025" />
          <stop offset=".5" stopColor="#283637" />
          <stop offset="1" stopColor="#101718" />
        </linearGradient>
        <linearGradient id={id("orange")} x1="0" y1="0" x2=".7" y2="1">
          <stop stopColor="#ed9b68" />
          <stop offset=".5" stopColor="#d77643" />
          <stop offset="1" stopColor="#a54d2e" />
        </linearGradient>
        <linearGradient id={id("steel")} x1="0" y1="0" x2="0" y2="1">
          <stop stopColor="#dce3dd" />
          <stop offset=".25" stopColor="#6b7775" />
          <stop offset=".5" stopColor="#b6c4bf" />
          <stop offset="1" stopColor="#4e5c5c" />
        </linearGradient>
        <radialGradient id={id("glow")}>
          <stop
            stopColor={station === "lathe" ? "#c07d55" : "#7eab91"}
            stopOpacity=".2"
          />
          <stop offset="1" stopColor="#172021" stopOpacity="0" />
        </radialGradient>
        <filter id={id("shadow")} x="-40%" y="-60%" width="180%" height="220%">
          <feGaussianBlur stdDeviation="13" />
        </filter>
      </defs>
      <ellipse
        cx="327"
        cy="315"
        rx="264"
        ry="44"
        fill={station === "lathe" ? "#d09162" : "#8ead9a"}
        opacity=".1"
        filter={`url(#${id("shadow")})`}
      />
      <ellipse
        cx="320"
        cy="336"
        rx="245"
        ry="24"
        fill="#050909"
        opacity=".7"
        filter={`url(#${id("shadow")})`}
      />
      <ellipse
        cx="315"
        cy="212"
        rx="295"
        ry="173"
        fill={`url(#${id("glow")})`}
      />
      <g strokeLinejoin="round">
        {station === "lathe" ? (
          <>
            <path
              d="M75 122 139 84 514 103 458 143Z"
              fill="#ccd0c7"
              stroke="#d7dad2"
              strokeWidth="1.4"
            />
            <path d="M458 143 514 103 514 297 458 330Z" fill="#505c5a" />
            <path
              d="M75 122 458 143 458 330 75 307Z"
              fill={`url(#${id("body")})`}
              stroke="#535e5b"
            />
            <path d="M76 277 458 300 458 330 76 307Z" fill="#56615e" />
            <path
              d="M87 310 119 312 119 326 87 324Z M411 330 442 332 442 344 411 343Z"
              fill="#222b2b"
            />
            <path
              d="M95 138 399 155 399 275 95 257Z"
              fill={`url(#${id("orange")})`}
              stroke="#a4502f"
            />
            <path
              d="M115 152 314 163 314 254 115 242Z"
              fill={`url(#${id("window")})`}
              stroke="#283334"
              strokeWidth="6"
            />
            <path d="M120 225 309 236 309 248 120 237Z" fill="#3c4847" />
            <path d="M132 213 293 222 280 231 125 222Z" fill="#64716d" />
            <path d="M132 165 163 166 163 213 132 211Z" fill="#4c5b58" />
            <ellipse
              cx="166"
              cy="191"
              rx="16"
              ry="25"
              fill={`url(#${id("steel")})`}
              stroke="#7f8b87"
            />
            <ellipse cx="170" cy="191" rx="9" ry="17" fill="#354240" />
            <path
              d="M172 181 226 185 226 203 172 201Z"
              fill={`url(#${id("steel")})`}
            />
            <ellipse cx="226" cy="194" rx="7" ry="9" fill="#a6b8af" />
            <path
              d="M258 174 280 175 286 201 263 202 251 190Z"
              fill="#889993"
            />
            <path
              d="M262 194 243 196 230 204 232 210 266 200Z"
              fill="#c1c7b5"
            />
            <path
              d="M132 155 214 160 139 242 119 241Z"
              fill="#fff"
              opacity=".035"
            />
            <path d="M323 161 384 165 384 262 323 258Z" fill="#be6039" />
            <path
              d="M335 184 335 231"
              stroke="#272e2e"
              strokeWidth="7"
              strokeLinecap="round"
            />
            <path
              d="M337 184 337 230"
              stroke="#ced0c4"
              strokeWidth="3"
              strokeLinecap="round"
            />
            <text
              x="112"
              y="283"
              fill="#e2e5da"
              fontSize="10"
              fontFamily="monospace"
              letterSpacing="3"
              transform="rotate(3.4 112 283)"
            >
              HORIZON / T-200
            </text>
            <path d="M413 161 448 163 448 240 413 238Z" fill="#34423f" />
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <path
                key={i}
                d={`M419 ${170 + i * 10} 442 ${171 + i * 10}`}
                stroke="#73817a"
                strokeWidth="2"
              />
            ))}
            <path
              d="M479 155 526 165 526 256 478 246Z"
              fill="#24312f"
              stroke="#697671"
              strokeWidth="2"
            />
            <path
              d="M485 165 518 172 518 203 485 196Z"
              fill="#111e1e"
              stroke="#475852"
            />
            <path
              d="M491 176 510 180 M491 181 505 184 M491 186 514 190"
              stroke="#91ad94"
              strokeWidth="1.6"
            />
            {Array.from({ length: 15 }, (_, i) => (
              <rect
                key={i}
                x={486 + (i % 5) * 6}
                y={207 + Math.floor(i / 5) * 7 + (i % 5)}
                width="3.5"
                height="3.5"
                rx=".6"
                fill="#93a198"
              />
            ))}
            <circle cx="493" cy="236" r="5" fill="#c89144" />
            <circle cx="510" cy="240" r="5" fill="#a74635" />
            <path d="M480 257 518 265 518 282 480 274Z" fill="#3c4946" />
            <path
              d="M493 286 493 318 516 320"
              fill="none"
              stroke="#384441"
              strokeWidth="6"
            />
            <path d="M421 115 421 85" stroke="#374640" strokeWidth="6" />
            <rect x="416" y="76" width="10" height="12" rx="3" fill="#a5c591" />
            <rect x="416" y="89" width="10" height="9" rx="2" fill="#b9964a" />
            <path
              d="M184 100 315 107"
              stroke="#f1f2e7"
              strokeOpacity=".5"
              strokeWidth="2"
            />
          </>
        ) : (
          <>
            <path d="M136 99 208 64 482 78 426 116Z" fill="#c6cec7" />
            <path d="M426 116 482 78 482 290 427 328Z" fill="#52635d" />
            <path
              d="M136 99 426 116 427 328 136 311Z"
              fill={`url(#${id("body")})`}
              stroke="#77857c"
            />
            <path d="M136 280 427 297 427 328 136 311Z" fill="#57695f" />
            <path d="M150 113 397 127 397 279 150 264Z" fill="#475f54" />
            <path
              d="M165 133 306 141 306 257 165 248Z"
              fill={`url(#${id("window")})`}
              stroke="#23362e"
              strokeWidth="5"
            />
            <path d="M317 142 380 146 380 262 317 258Z" fill="#7f9988" />
            <path
              d="M329 169 329 232"
              stroke="#253b31"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <path
              d="M331 169 331 232"
              stroke="#c3d0c0"
              strokeWidth="2"
              strokeLinecap="round"
            />
            <path d="M216 150 253 152 253 181 216 179Z" fill="#929f96" />
            <path
              d="M225 179 246 181 241 207 231 206Z"
              fill={`url(#${id("steel")})`}
            />
            <path d="M236 205 236 219" stroke="#cad4c4" strokeWidth="4" />
            <ellipse cx="278" cy="163" rx="16" ry="12" fill="#5f7666" />
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <circle
                key={i}
                cx={278 + Math.cos((i * Math.PI) / 3) * 11}
                cy={163 + Math.sin((i * Math.PI) / 3) * 7}
                r="2.3"
                fill="#b4c6b5"
              />
            ))}
            <path d="M181 228 273 233 292 245 180 239Z" fill="#8c9e91" />
            <path d="M196 219 258 223 270 232 198 229Z" fill="#d0d6c6" />
            <path d="M198 229 270 232 270 242 198 238Z" fill="#687e6c" />
            <path d="M207 216 248 218 256 224 213 223Z" fill="#bdc9b8" />
            <path d="M192 243 285 248" stroke="#273d31" strokeWidth="3" />
            <path d="M175 135 221 137 170 222Z" fill="#fff" opacity=".04" />
            <text
              x="159"
              y="292"
              fill="#e0e5d9"
              fontSize="10"
              fontFamily="monospace"
              letterSpacing="3"
              transform="rotate(3.4 159 292)"
            >
              VERTEX / V-55
            </text>
            <path
              d="M451 150 511 160 511 253 451 244Z"
              fill="#2e4036"
              stroke="#899b8c"
              strokeWidth="2"
            />
            <path d="M458 159 503 167 503 203 458 196Z" fill="#11251c" />
            <path
              d="M465 171 495 176 M465 178 481 181 M465 184 491 188"
              stroke="#92b89c"
              strokeWidth="1.5"
            />
            {Array.from({ length: 18 }, (_, i) => (
              <rect
                key={i}
                x={458 + (i % 6) * 7}
                y={207 + Math.floor(i / 6) * 7 + (i % 6)}
                width="4"
                height="4"
                rx="1"
                fill="#91a48e"
              />
            ))}
            <circle cx="465" cy="235" r="5" fill="#bc9948" />
            <circle cx="491" cy="239" r="5" fill="#b55b42" />
            <path d="M479 255 479 310" stroke="#334b3d" strokeWidth="7" />
            <path
              d="M160 313 189 315 189 329 160 327 M382 326 410 328 410 341 382 339"
              fill="#26382d"
            />
            <path d="M389 90 389 57" stroke="#3e5144" strokeWidth="5" />
            <rect x="384" y="49" width="10" height="13" rx="3" fill="#a9d09d" />
          </>
        )}
      </g>
    </svg>
  );
}
