import { ArrowLeft, ArrowRight, Check, RotateCcw, Trophy } from "lucide-react";
import { inspect, inTolerance } from "../domain/game";
import { operations } from "../data/shop";
import type { GameState } from "../domain/types";
import { StockCanvas } from "./StockCanvas";
import { Button, formatTime, Meter } from "./ui";
export function Results({
  state,
  onReplay,
  onBack,
  onTraveler,
}: {
  state: GameState;
  onReplay: () => void;
  onBack: () => void;
  onTraveler: () => void;
}) {
  const score = inspect(state);
  return (
    <div className="results-page page-enter">
      <div className="page-heading">
        <div>
          <p className="eyebrow">
            <span className="orange-dash" /> FINAL INSPECTION /{" "}
            {state.mode === "practice" ? "PRACTICE" : "JOB-001"}
          </p>
          <h1>That’s a part well made.</h1>
          <p className="muted">
            From a blank to something with purpose. Nice work on the floor.
          </p>
        </div>
        <Button
          tip="Return to the shop dashboard"
          className="subtle"
          onClick={onBack}
        >
          <ArrowLeft size={15} /> Back to shop
        </Button>
      </div>
      <div className="results-layout">
        <section className="finished-part panel">
          <div className="panel-title">
            <span className="eyebrow">
              {state.mode === "practice"
                ? "BILLET DETAIL STUDY"
                : "ALUMINUM WHEEL HUB"}
            </span>
            <span className="pill">
              <Check size={12} /> ACCEPTED
            </span>
          </div>
          <StockCanvas
            state={state}
            station="mill"
            preview={false}
            coolant={false}
          />
          <div className="finished-caption">
            <span className="mono">
              PART / {state.mode === "practice" ? "PR-001" : "WH-001"}
            </span>
            <span>Your finished features, ready for inspection.</span>
          </div>
        </section>
        <section className="score-card panel">
          <p className="eyebrow">CRAFTSMANSHIP SCORE</p>
          <div className="score-display">
            <strong>
              {score.overall}
              <small>/100</small>
            </strong>
            <span className="grade">{score.grade}</span>
          </div>
          <p className="muted">
            {score.overall >= 95
              ? "A little precision goes a long way."
              : score.overall >= 85
                ? "A solid result. There’s always another level."
                : "Every part is a chance to learn."}
          </p>
          <div className="score-metrics">
            {(
              [
                ["Dimensions & tolerance", score.accuracy],
                ["Surface finish", score.finish],
                ["Cycle efficiency", score.time],
                ["Tool choices", score.tooling],
                ["Error-free work", score.safety],
              ] as const
            ).map(([label, value]) => (
              <div key={label}>
                <div>
                  <span>{label}</span>
                  <span className="mono">{value}</span>
                </div>
                <Meter value={value} />
              </div>
            ))}
          </div>
          <div className="reward-box">
            <Trophy size={24} />
            <div>
              <span>
                {state.mode === "practice" ? "PRACTICE COMPLETE" : "JOB REWARD"}
              </span>
              <strong>
                {state.mode === "practice"
                  ? "Experience earned"
                  : `+ ${score.reward} credits`}
              </strong>
            </div>
          </div>
          <Button
            tip="Start this session again with fresh stock"
            className="primary full"
            onClick={onReplay}
          >
            <RotateCcw size={16} /> Make another
          </Button>
        </section>
      </div>
      <div className="completion-strip">
        <div>
          <span className="eyebrow">FEATURES ACCEPTED</span>
          <strong>
            {
              operations.filter(
                (op) =>
                  (state.mode === "job" || op.station === "mill") &&
                  inTolerance(op, state.results[op.id]),
              ).length
            }
          </strong>
        </div>
        <div>
          <span className="eyebrow">ACTIVE CYCLE TIME</span>
          <strong className="mono">{formatTime(state.elapsed)}</strong>
        </div>
        <div>
          <span className="eyebrow">VIRTUAL INTERLOCKS</span>
          <strong>{state.errors}</strong>
        </div>
        <Button
          tip="Review all targets and feature inspection statuses"
          className="subtle"
          onClick={onTraveler}
        >
          Review traveler <ArrowRight size={16} />
        </Button>
      </div>
    </div>
  );
}
