import {
  ArrowDownRight,
  ArrowRight,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Crosshair,
  Layers3,
  RotateCcw,
  Sparkles,
  Target,
} from "lucide-react";
import { machines, hubJob } from "../data/shop";
import { completedCount, requiredCount } from "../domain/game";
import type { GameState, Station } from "../domain/types";
import { MachineArt } from "./MachineArt";
import { Button, Meter } from "./ui";
export function Home({
  state,
  onStation,
  onStart,
  onTraveler,
  onTutorial,
  onReset,
  onPractice,
}: {
  state: GameState;
  onStation: (station: Station) => void;
  onStart: () => void;
  onTraveler: () => void;
  onTutorial: () => void;
  onReset: () => void;
  onPractice: () => void;
}) {
  const started = Object.keys(state.results).length > 0;
  const complete = state.stage === "complete";
  const progress = (completedCount(state) / requiredCount()) * 100;
  return (
    <div className="home-page page-enter">
      <div className="page-heading">
        <div>
          <p className="eyebrow">
            <span className="orange-dash" /> YOUR VIRTUAL WORKSHOP
          </p>
          <h1>Good things take shape.</h1>
          <p className="muted">
            A little precision. A lot of possibility. Make your first part.
          </p>
        </div>
        <Button
          tip="Start over with a fresh Aluminum Wheel Hub job"
          className="subtle"
          onClick={onReset}
        >
          <RotateCcw size={15} /> New shift
        </Button>
      </div>
      <div className="home-grid">
        <section className="hero-panel">
          <div className="hero-top">
            <span className="pill">
              <span className="status-dot" /> SHOP ONLINE
            </span>
            <span className="mono faint">EST. 2026 / BAY 01</span>
          </div>
          <div className="hero-copy">
            <p className="eyebrow">PRECISION IS A PRACTICE</p>
            <h2>
              From raw stock.
              <br />
              To something <em>remarkable.</em>
            </h2>
            <p>
              Step onto the floor. Pick your tools.
              <br />
              Find the part waiting inside.
            </p>
          </div>
          <div className="hero-machine">
            <MachineArt station="lathe" />
          </div>
          <div className="hero-coordinate">
            <span>01</span>
            <div>
              HORIZON T-200<small>TURNING CENTER</small>
            </div>
            <span className="coordinate-line" />
            <Crosshair size={17} />
          </div>
          <div className="hero-footer">
            <span>
              <span className="tiny-square" /> TWO MACHINES. ONE GREAT FIRST
              PART.
            </span>
            <ArrowDownRight size={22} />
          </div>
        </section>
        <section className="job-card">
          <div className="section-kicker">
            <span className="eyebrow">ON THE JOB BOARD</span>
            <span className="badge">BEGINNER</span>
          </div>
          <div className="job-object" aria-hidden="true">
            <HubSketch />
            <span className="object-code mono">PART / WH-001</span>
          </div>
          <p className="mono orange job-number">
            {hubJob.id} <span> / </span> FORM + FUNCTION
          </p>
          <h2>
            Aluminum
            <br />
            Wheel Hub
          </h2>
          <p className="muted job-description">
            One blank. Two setups.
            <br />
            Your introduction to making things.
          </p>
          <div className="job-meta">
            <span>
              <Clock3 size={14} /> 5–8 min
            </span>
            <span>
              <Layers3 size={14} /> 2 stages
            </span>
            <span className="reward">850 cr</span>
          </div>
          <div className="job-progress">
            <div>
              <span>
                {complete
                  ? "Job complete"
                  : started
                    ? "Job in progress"
                    : "Ready when you are"}
              </span>
              <span className="mono">
                {completedCount(state)}/{requiredCount()}
              </span>
            </div>
            <Meter value={progress} />
          </div>
          <Button
            tip={
              complete
                ? "View the finished part and your inspection results"
                : "Open the current machine station and work on the wheel hub"
            }
            className="primary full"
            onClick={onStart}
          >
            {complete
              ? "View inspection"
              : started
                ? "Continue job"
                : "Start your first job"}
            <ArrowRight size={17} />
          </Button>
          <Button
            tip="Read the part specifications, virtual setup, and quality checklist"
            className="text-button full"
            onClick={onTraveler}
          >
            View job traveler <ChevronRight size={14} />
          </Button>
        </section>
      </div>
      <div className="section-heading">
        <div>
          <h2>
            Your shop floor <span>02 stations</span>
          </h2>
          <p className="muted">
            Different machines. A shared attention to detail.
          </p>
        </div>
        <span className="mono faint floor-label">
          <span className="status-dot" /> ALL SYSTEMS VIRTUAL
        </span>
      </div>
      <div className="machine-grid">
        {machines.map((machine, i) => (
          <button
            className={`machine-card machine-${machine.id}`}
            key={machine.id}
            onClick={() => onStation(machine.id)}
            title={`Explore the ${machine.brand} ${machine.name} virtual ${machine.type.toLowerCase()}`}
          >
            <div className="machine-card-top">
              <span className="mono faint">
                0{i + 1} / {machine.type}
              </span>
              <span className="machine-badge">{machine.axes}</span>
            </div>
            <MachineArt station={machine.id} />
            <div className="machine-card-bottom">
              <div>
                <h3>
                  {machine.brand === "HORIZON" ? "Horizon" : "Vertex"}{" "}
                  <span>{machine.name}</span>
                </h3>
                <p>{machine.description}</p>
              </div>
              <span className="round-arrow">
                <ArrowRight size={19} />
              </span>
            </div>
          </button>
        ))}
      </div>
      <div className="learn-strip">
        <div className="learn-icon">
          <Sparkles size={19} />
        </div>
        <div>
          <h3>Your first day on the floor?</h3>
          <p>Learn the controls with a quick, hands-on walkthrough.</p>
        </div>
        <Button
          tip="Start an interactive walkthrough at the current station"
          className="subtle"
          onClick={onTutorial}
        >
          Show me around <ArrowRight size={15} />
        </Button>
        <Button
          tip="Experiment with the mill and a rectangular billet without changing your job"
          className="text-button practice-link"
          onClick={onPractice}
        >
          Billet practice <ChevronRight size={14} />
        </Button>
      </div>
      <footer className="page-footer">
        <span>
          <CircleHelp size={13} /> A fictional workshop. Real curiosity.
        </span>
        <span>
          SIMULATION ONLY <span className="footer-dot">·</span> NO REAL
          MACHINERY
        </span>
      </footer>
    </div>
  );
}
export function HubSketch({ large = false }: { large?: boolean }) {
  return (
    <svg
      className={`hub-sketch ${large ? "large" : ""}`}
      viewBox="0 0 300 220"
      role="img"
      aria-label="Illustrated finished aluminum wheel hub with a stepped center and six bolt holes"
    >
      <defs>
        <linearGradient id="hub-side" x1="0" y1="0" x2="1" y2="0">
          <stop stopColor="#5e7566" />
          <stop offset=".4" stopColor="#cad5c2" />
          <stop offset="1" stopColor="#526b5b" />
        </linearGradient>
        <linearGradient id="hub-top" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#cdd5bf" />
          <stop offset=".5" stopColor="#98ad96" />
          <stop offset="1" stopColor="#617f68" />
        </linearGradient>
      </defs>
      <ellipse cx="150" cy="176" rx="110" ry="26" fill="#080f0a" opacity=".3" />
      <path
        d="M45 119V143C45 211 255 211 255 143V119Z"
        fill="url(#hub-side)"
        stroke="#b6c3a3"
        strokeWidth=".7"
      />
      <ellipse
        cx="150"
        cy="119"
        rx="105"
        ry="54"
        fill="url(#hub-top)"
        stroke="#cbd5b7"
      />
      <ellipse
        cx="150"
        cy="120"
        rx="96"
        ry="47"
        fill="none"
        stroke="#d3d9be"
        opacity=".25"
      />
      <path
        d="M93 84V124C93 160 207 160 207 124V84Z"
        fill="url(#hub-side)"
        stroke="#c5d0b3"
      />
      <ellipse
        cx="150"
        cy="84"
        rx="57"
        ry="29"
        fill="url(#hub-top)"
        stroke="#d6ddc1"
      />
      <path
        d="M112 66V84C112 109 188 109 188 84V66Z"
        fill="url(#hub-side)"
        stroke="#b3c4a4"
      />
      <ellipse
        cx="150"
        cy="66"
        rx="38"
        ry="20"
        fill="url(#hub-top)"
        stroke="#d5dfc2"
      />
      <ellipse
        cx="150"
        cy="66"
        rx="17"
        ry="9"
        fill="#233a2a"
        stroke="#ced8bb"
      />
      {[
        [-78, 0],
        [-50, 37],
        [49, 37],
        [79, 0],
        [-50, -35],
        [50, -35],
      ].map(([x, y], i) => (
        <ellipse
          key={i}
          cx={150 + x}
          cy={119 + y}
          rx="8"
          ry="4.5"
          fill="#304932"
          stroke="#d0d9bb"
        />
      ))}
      <path
        d="M32 117H13M150 30V15M265 117H285M150 191V211"
        stroke="#c2caaa"
        opacity=".45"
      />
      <path
        d="M13 112V122M145 15H155M285 112V122M145 211H155"
        stroke="#c2caaa"
        opacity=".4"
      />
    </svg>
  );
}
export function StageBadge({
  done,
  children,
}: {
  done: boolean;
  children: React.ReactNode;
}) {
  return (
    <span className={`stage-badge ${done ? "done" : ""}`}>
      {done ? <Check size={12} /> : <Target size={12} />} {children}
    </span>
  );
}
