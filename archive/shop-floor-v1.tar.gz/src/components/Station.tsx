import { useEffect, useState } from "react";
import type { Dispatch } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronRight,
  CircleHelp,
  Crosshair,
  Droplets,
  Eye,
  FileText,
  Gauge,
  Maximize2,
  Pause,
  Play,
  RotateCcw,
  Settings2,
  ShieldCheck,
  Square,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { machines, operations, tools } from "../data/shop";
import {
  completedCount,
  inTolerance,
  requiredCount,
  stageReady,
} from "../domain/game";
import type { GameAction } from "../domain/game";
import type { GameState, Station as StationType } from "../domain/types";
import { useSound } from "../hooks/useSound";
import { StockCanvas } from "./StockCanvas";
import { Button, formatTime, Meter, Modal } from "./ui";

export function Station({
  state,
  dispatch,
  station,
  onBack,
  onTraveler,
  onAdvance,
  tutorial,
  setTutorial,
  onPractice,
  onReset,
}: {
  state: GameState;
  dispatch: Dispatch<GameAction>;
  station: StationType;
  onBack: () => void;
  onTraveler: () => void;
  onAdvance: () => void;
  tutorial: boolean;
  setTutorial: (show: boolean) => void;
  onPractice: () => void;
  onReset: () => void;
}) {
  const stationOps = operations.filter((op) => op.station === station);
  const [selected, setSelected] = useState(
    () =>
      (state.active &&
      stationOps.some((item) => item.id === state.active?.operationId)
        ? state.active.operationId
        : undefined) ??
      stationOps.find(
        (op) => op.required && !inTolerance(op, state.results[op.id]),
      )?.id ??
      stationOps[0].id,
  );
  const op = operations.find((item) => item.id === selected)!;
  const [value, setValue] = useState(state.active?.value ?? op.initial);
  const [tool, setTool] = useState(state.active?.toolId ?? "");
  const [feed, setFeed] = useState(state.active?.feed ?? 90);
  const [spindle, setSpindle] = useState(state.active?.spindle ?? 100);
  const [coolant, setCoolant] = useState(true);
  const [preview, setPreview] = useState(true);
  const [sound, setSound] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const machine = machines.find((item) => item.id === station)!;
  const active = !!state.active;
  const running = active && !state.paused;
  const result = state.results[op.id];
  const passed = inTolerance(op, result);
  const locked = state.stage !== station;
  const ready = stageReady(state, station);
  const prerequisites = op.dependsOn.filter(
    (id) =>
      !inTolerance(
        operations.find((item) => item.id === id)!,
        state.results[id],
      ),
  );
  const guideStep = result
    ? 3
    : tool !== op.tool
      ? 0
      : Math.abs(value - op.target) > op.tolerance
        ? 1
        : 2;
  useSound(sound, running, spindle);
  useEffect(() => {
    setValue(
      state.active?.operationId === selected
        ? state.active.value
        : (state.results[selected]?.value ?? op.initial),
    );
  }, [selected, op.initial]);
  const selectOp = (id: string) => {
    if (!active) setSelected(id);
  };
  const nextOp = () => {
    const next = stationOps.find(
      (item) =>
        item.required &&
        !inTolerance(item, state.results[item.id]) &&
        item.id !== op.id,
    );
    if (next) selectOp(next.id);
  };
  return (
    <div className="station-page page-enter">
      <div className="station-heading">
        <div className="station-title">
          <Button
            tip="Return to your shop dashboard; any active cut will be held"
            className="icon-button back-button"
            aria-label="Back to shop floor"
            onClick={onBack}
          >
            <ArrowLeft size={20} />
          </Button>
          <div>
            <p className="eyebrow">
              {state.mode === "practice"
                ? "BILLET PRACTICE / FREE PLAY"
                : `JOB-001 / STAGE ${station === "lathe" ? "01" : "02"} OF 02`}
            </p>
            <h1>
              {machine.brand === "HORIZON" ? "Horizon" : "Vertex"}{" "}
              <span>{machine.name}</span>
            </h1>
          </div>
        </div>
        <div className="heading-actions">
          <Button
            tip="Read the job specifications and quality checks"
            className="subtle"
            onClick={onTraveler}
          >
            <FileText size={15} /> Job traveler
          </Button>
          <Button
            tip="Show the interactive guide for the selected operation"
            className="icon-button"
            aria-label="Show interactive tutorial"
            onClick={() => setTutorial(!tutorial)}
          >
            <CircleHelp size={19} />
          </Button>
        </div>
      </div>
      {locked && (
        <div className="notice">
          <ShieldCheck size={20} />
          <div>
            <strong>
              {state.stage === "complete"
                ? "This part has passed final inspection."
                : station === "mill"
                  ? "Your hub starts at the lathe."
                  : "The turning stage is complete."}
            </strong>
            <p>
              {state.stage === "complete"
                ? "Your finished geometry is saved. Start a new shift or explore the mill with a separate practice billet."
                : station === "mill"
                  ? "Finish the turning stage to transfer your part here, or explore the mill with a practice billet."
                  : "Your finished profile is ready. Continue the job at the mill."}
            </p>
          </div>
          <Button
            tip={
              station === "mill"
                ? "Start independent mill practice with rectangular stock"
                : "Return to the shop dashboard"
            }
            className="subtle"
            onClick={station === "mill" ? onPractice : onBack}
          >
            {station === "mill" ? "Try billet practice" : "Back to shop"}
            <ArrowRight size={14} />
          </Button>
        </div>
      )}
      {tutorial && !locked && (
        <div className="tutorial-banner">
          <div className="tutorial-icon">
            <Crosshair size={22} />
          </div>
          <div className="tutorial-text">
            <p className="eyebrow">
              SHOP FLOOR BASICS <span>{guideStep + 1} / 4</span>
            </p>
            <strong>
              {
                [
                  "Every feature starts with a tool.",
                  "Meet your target.",
                  "Let’s make some chips.",
                  "A good part starts with a good check.",
                ][guideStep]
              }
            </strong>
            <p>
              {
                [
                  `Select ${tools.find((item) => item.id === op.tool)?.name} from the tool rack below. The orange marker is your guide.`,
                  `Move the ${op.parameter.toLowerCase()} slider to ${op.target} ${op.unit}. The target and tolerance are always visible.`,
                  `Press Cycle Start. Try Feed Hold to pause, then resume. These controls affect only this game.`,
                  passed
                    ? "Your feature passed. Choose the next operation, or dismiss this guide and keep going."
                    : "This feature needs another attempt. Use Redo operation and adjust the value to the target.",
                ][guideStep]
              }
            </p>
          </div>
          <Button
            tip="Dismiss the tutorial; reopen it with the question mark button"
            className="icon-button"
            aria-label="Dismiss tutorial"
            onClick={() => setTutorial(false)}
          >
            <X size={17} />
          </Button>
        </div>
      )}
      <div className="station-layout">
        <aside className="operations-panel panel">
          <div className="panel-title">
            <span className="eyebrow">THE PROCESS</span>
            <span className="mono faint">
              {completedCount(state, station)}/{requiredCount(station)}
            </span>
          </div>
          <h3>
            {state.mode === "practice"
              ? "A blank canvas."
              : station === "lathe"
                ? "Find the profile."
                : "Make it functional."}
          </h3>
          <p className="small muted">
            {station === "lathe"
              ? "Round stock → stepped hub"
              : state.mode === "practice"
                ? "Rectangular billet → detail study"
                : "Turned hub → finished part"}
          </p>
          <div className="operation-list">
            {stationOps.map((item, i) => {
              const r = state.results[item.id];
              const done = inTolerance(item, r);
              return (
                <button
                  key={item.id}
                  title={`${item.description}${item.required ? " Required for this stage." : " Optional finishing feature."}`}
                  className={`operation-item ${selected === item.id ? "selected" : ""} ${done ? "done" : ""}`}
                  disabled={active}
                  onClick={() => selectOp(item.id)}
                >
                  <span
                    className={`operation-number ${r && !done ? "failed" : ""}`}
                  >
                    {done ? (
                      <Check size={14} />
                    ) : (
                      String(i + 1).padStart(2, "0")
                    )}
                  </span>
                  <span>
                    {item.name}
                    <small>
                      {done
                        ? "Within tolerance"
                        : r
                          ? "Needs another pass"
                          : item.required
                            ? "Required feature"
                            : "Optional detail"}
                    </small>
                  </span>
                  {selected === item.id && <ChevronRight size={14} />}
                </button>
              );
            })}
          </div>
          <div className="process-footer">
            <ShieldCheck size={17} />
            <p>
              Experiment freely.
              <br />
              <span>Every operation is recoverable.</span>
            </p>
          </div>
        </aside>
        <div className="work-area">
          <section className="viewport panel">
            <div className="viewport-toolbar">
              <span className="viewport-label">
                <span className={`status-dot ${running ? "pulsing" : ""}`} />
                {running
                  ? "CUTTING"
                  : state.paused
                    ? "FEED HOLD"
                    : "VIRTUAL WORKSPACE"}
              </span>
              <div>
                <Button
                  tip="Toggle the ghost target. Graphics preview is visual only and never changes stock"
                  className={`icon-button ${preview ? "toggled" : ""}`}
                  aria-label="Toggle graphics preview"
                  aria-pressed={preview}
                  onClick={() => setPreview(!preview)}
                >
                  <Eye size={16} />
                </Button>
                <Button
                  tip="Enlarge the virtual stock view"
                  className="icon-button"
                  aria-label="Enlarge stock view"
                  onClick={() => setFullscreen(true)}
                >
                  <Maximize2 size={16} />
                </Button>
              </div>
            </div>
            <StockCanvas
              state={state}
              station={station}
              preview={preview}
              coolant={coolant}
            />
            <div className="viewport-status">
              <span>
                <span className="target-line" />
                {preview ? "TARGET OVERLAY ON" : "TARGET OVERLAY OFF"}
              </span>
              <span className="mono">
                {station === "lathe"
                  ? "6061 / ROUND STOCK"
                  : state.mode === "practice"
                    ? "6061 / RECTANGULAR BILLET"
                    : "6061 / TURNED HUB"}
              </span>
            </div>
            <div className="cut-progress">
              <Meter value={(state.active?.progress ?? 0) * 100} />
            </div>
          </section>
          <section className="tool-rack panel">
            <div className="panel-title">
              <span className="eyebrow">
                {station === "lathe" ? "VIRTUAL TURRET" : "TOOL CAROUSEL"}
              </span>
              <span className="mono faint">04 TOOLS</span>
            </div>
            <div className="tools">
              {tools
                .filter((item) => item.station === station)
                .map((item) => (
                  <button
                    key={item.id}
                    className={`tool-item ${tool === item.id ? "selected" : ""} ${item.id === op.tool ? "suggested" : ""}`}
                    title={`${item.name}: used for ${item.kind.toLowerCase()} operations in this fictional station`}
                    onClick={() => setTool(item.id)}
                    disabled={active || locked}
                  >
                    <span className="tool-glyph">
                      <ToolGlyph type={item.id} />
                    </span>
                    <span className="tool-number">
                      {item.number}
                      {tool === item.id && <Check size={11} />}
                    </span>
                    <strong>{item.name}</strong>
                    <small>{item.kind}</small>
                  </button>
                ))}
            </div>
          </section>
          <div className="station-bottom">
            <span>
              <ShieldCheck size={13} /> FICTIONAL CONTROLS · NO MACHINE
              CONNECTION
            </span>
            <Button
              tip="Clear this session and start with fresh virtual stock"
              className="text-button"
              onClick={onReset}
            >
              <RotateCcw size={13} /> Reset{" "}
              {state.mode === "practice" ? "practice" : "job"}
            </Button>
          </div>
        </div>
        <aside className="control-panel panel">
          <div className="panel-title">
            <span className="eyebrow">CONTROL DESK</span>
            <Settings2 size={15} className="faint" />
          </div>
          <h3>{op.name}</h3>
          <p className="control-description">{op.description}</p>
          <div className="target-box">
            <span>TARGET / {op.parameter.toUpperCase()}</span>
            <div>
              {op.target.toFixed(op.target % 1 ? 1 : 0)}{" "}
              <small>{op.unit}</small>
              <span>
                ± {op.tolerance} {op.unit}
              </span>
            </div>
          </div>
          <label className="parameter-control">
            <span>
              {op.parameter}
              <output>
                {value.toFixed(1)} <small>{op.unit}</small>
              </output>
            </span>
            <input
              type="range"
              min={op.min}
              max={op.max}
              step="0.1"
              value={value}
              disabled={active || !!result || locked}
              onChange={(e) => setValue(Number(e.target.value))}
              title={`Edit ${op.parameter.toLowerCase()} in fictional ${op.unit}. Target ${op.target}, tolerance plus or minus ${op.tolerance}`}
              aria-label={op.parameter}
            />
            <span className="range-limits">
              <span>
                {op.min} {op.unit}
              </span>
              <span>
                {op.max} {op.unit}
              </span>
            </span>
          </label>
          <div className="override-controls">
            <Override
              name="Feed"
              value={feed}
              onChange={setFeed}
              disabled={active}
              tip="Game speed and finish modifier. 90% gives the smoothest virtual finish."
            />
            <Override
              name="Spindle"
              value={spindle}
              onChange={setSpindle}
              disabled={active}
              tip="Virtual spindle and finish modifier. 100% is the balanced game setting."
            />
          </div>
          <div className="utility-controls">
            <Button
              tip="Toggle decorative coolant particles"
              className={`utility-button ${coolant ? "toggled" : ""}`}
              onClick={() => setCoolant(!coolant)}
              aria-pressed={coolant}
            >
              <Droplets size={15} /> Coolant{" "}
              <span>{coolant ? "ON" : "OFF"}</span>
            </Button>
            <Button
              tip="Toggle synthesized virtual machine audio"
              className={`utility-button ${sound ? "toggled" : ""}`}
              onClick={() => setSound(!sound)}
              aria-pressed={sound}
            >
              {sound ? <Volume2 size={15} /> : <VolumeX size={15} />} Sound{" "}
              <span>{sound ? "ON" : "OFF"}</span>
            </Button>
          </div>
          <div className="cycle-controls">
            <Button
              tip={
                state.paused
                  ? "Resume the held virtual cycle"
                  : "Run the selected fictional operation with your selected tool and parameter"
              }
              className="primary full cycle-start"
              disabled={
                locked ||
                (!state.paused &&
                  (active || !!result || prerequisites.length > 0))
              }
              onClick={() =>
                state.paused
                  ? dispatch({ type: "hold" })
                  : dispatch({
                      type: "start",
                      operationId: op.id,
                      value,
                      toolId: tool,
                      feed,
                      spindle,
                    })
              }
            >
              <Play size={17} fill="currentColor" />
              {state.paused
                ? "Resume cycle"
                : running
                  ? "Cycle running…"
                  : "Cycle Start"}
              {running && (
                <span className="mono">
                  {Math.round(state.active!.progress * 100)}%
                </span>
              )}
            </Button>
            <div className="cycle-secondary">
              <Button
                tip="Pause or resume the current virtual cut and its cycle timer"
                disabled={!active || locked}
                className="subtle"
                onClick={() => dispatch({ type: "hold" })}
              >
                <Pause size={14} />
                {state.paused ? "Resume" : "Feed Hold"}
              </Button>
              <Button
                tip="Cancel the active cycle and restore the last completed geometry"
                className="subtle"
                disabled={!active || locked}
                onClick={() => dispatch({ type: "reset-cycle" })}
              >
                <Square size={12} /> Reset
              </Button>
            </div>
          </div>
          <div className="feedback" aria-live="polite">
            {result ? (
              <div className={`result-box ${passed ? "pass" : "fail"}`}>
                <span>
                  {passed ? <Check size={16} /> : <Crosshair size={16} />}{" "}
                  {passed ? "Feature accepted" : "Outside tolerance"}
                </span>
                <p>
                  Measured {result.value.toFixed(1)} {op.unit} <span>·</span>{" "}
                  {Math.abs(result.value - op.target).toFixed(1)} deviation
                </p>
                <Button
                  tip="Restore this feature and any dependent features for another attempt"
                  className="text-button"
                  disabled={active || locked}
                  onClick={() => dispatch({ type: "redo", operationId: op.id })}
                >
                  <RotateCcw size={13} /> Redo operation
                </Button>
                {passed && !ready && (
                  <Button
                    tip="Select the next unfinished required operation"
                    className="text-button"
                    onClick={nextOp}
                  >
                    Next feature <ArrowRight size={13} />
                  </Button>
                )}
              </div>
            ) : prerequisites.length > 0 ? (
              <p className="hint">
                First complete:{" "}
                {prerequisites
                  .map((id) => operations.find((item) => item.id === id)!.name)
                  .join(", ")}
                .
              </p>
            ) : (
              <p className="hint">
                <CircleHelp size={13} />{" "}
                {tool
                  ? `Selected: ${tools.find((item) => item.id === tool)?.name}.`
                  : "Choose a tool from the rack to begin."}
              </p>
            )}
            {state.message && (
              <p
                className={`machine-message ${state.message.includes("mismatch") ? "warning" : ""}`}
              >
                {state.message}
              </p>
            )}
          </div>
          <div className="cycle-time">
            <span>
              <ClockIcon /> VIRTUAL CYCLE TIME
            </span>
            <strong className="mono">{formatTime(state.elapsed)}</strong>
          </div>
          {ready && !locked && (
            <Button
              tip={
                station === "lathe"
                  ? "Transfer the completed hub to the milling stage"
                  : "Inspect the finished part and view your score"
              }
              className="success-button full"
              disabled={active}
              onClick={onAdvance}
            >
              {station === "lathe" ? "Transfer to mill" : "Finish & inspect"}
              <ArrowRight size={16} />
            </Button>
          )}
        </aside>
      </div>
      {fullscreen && (
        <Modal
          title={
            station === "lathe"
              ? "A closer look at the profile"
              : "A closer look at the details"
          }
          subtitle="VIRTUAL GEOMETRY"
          wide
          onClose={() => setFullscreen(false)}
        >
          <StockCanvas
            state={state}
            station={station}
            preview={preview}
            coolant={coolant}
          />
          <p className="modal-note">
            {preview
              ? "The dashed orange lines show the fictional target."
              : "The target overlay is currently off."}{" "}
            Close this view to adjust your next operation.
          </p>
        </Modal>
      )}
    </div>
  );
}
function Override({
  name,
  value,
  onChange,
  disabled,
  tip,
}: {
  name: string;
  value: number;
  onChange: (value: number) => void;
  disabled: boolean;
  tip: string;
}) {
  return (
    <label className="override">
      <span>
        {name} override <output>{value}%</output>
      </span>
      <input
        type="range"
        min="50"
        max="150"
        step="5"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        disabled={disabled}
        aria-label={`${name} override`}
        title={tip}
      />
    </label>
  );
}
function ClockIcon() {
  return <Gauge size={14} />;
}
function ToolGlyph({ type }: { type: string }) {
  return (
    <svg viewBox="0 0 70 45" aria-hidden="true">
      {type === "turning" || type === "grooving" ? (
        <>
          <path d="M17 9H38V30H17Z" fill="#6e7a71" />
          <path
            d="M17 27 40 27 27 40Z"
            fill={type === "turning" ? "#d9ad75" : "#b8bfa3"}
          />
          <circle cx="28" cy="29" r="3" fill="#3c483d" />
        </>
      ) : type === "facing" || type === "chamfer" ? (
        <>
          <path d="M29 3H40V24H29Z" fill="#75867a" />
          <path d="M18 24H51L45 37H24Z" fill="#b6bda6" />
          {[24, 34, 44].map((x) => (
            <path key={x} d={`M${x} 29V39`} stroke="#dbc289" strokeWidth="3" />
          ))}
        </>
      ) : (
        <>
          <path d="M28 3H40V20H28Z" fill="#768278" />
          <path d="M28 20H40V35L34 41 28 35Z" fill="#bbbc9c" />
          <path d="M28 22 40 28M28 29 40 35" stroke="#66745e" strokeWidth="3" />
        </>
      )}
    </svg>
  );
}
