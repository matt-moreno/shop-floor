import { Check, ClipboardList, ShieldCheck } from "lucide-react";
import { hubJob, operations, tools } from "../data/shop";
import { inTolerance } from "../domain/game";
import type { GameState } from "../domain/types";
import { Button, Modal } from "./ui";
export function Traveler({
  state,
  onClose,
}: {
  state: GameState;
  onClose: () => void;
}) {
  const practice = state.mode === "practice";
  return (
    <Modal
      title={practice ? "Billet practice traveler" : hubJob.name}
      subtitle={
        practice
          ? "PRACTICE / NO JOB PROGRESS CHANGES"
          : `${hubJob.id} / FORM + MOTION LAB`
      }
      wide
      onClose={onClose}
    >
      <div className="traveler-summary">
        <div>
          <span>STOCK</span>
          <strong>
            {practice ? "Rectangular billet" : "Round aluminum blank"}
          </strong>
          <small>
            {practice ? "80 × 70 × 20 gu" : "Ø 80 × 64 gu"} · fictional units
          </small>
        </div>
        <div>
          <span>ROUTE</span>
          <strong>{practice ? "Vertex V-55" : "Horizon → Vertex"}</strong>
          <small>{practice ? "1 practice setup" : "2 virtual setups"}</small>
        </div>
        <div>
          <span>REWARD</span>
          <strong>{practice ? "Practice score" : "Up to 850 credits"}</strong>
          <small>
            {practice ? "Experiment & repeat" : "Quality determines payout"}
          </small>
        </div>
      </div>
      <div className="traveler-note">
        <ShieldCheck size={21} />
        <p>
          This traveler describes a game, not a machining process. All
          dimensions are fictional game units (gu). These simplified actions
          cannot operate or program a real machine.
        </p>
      </div>
      <div className="traveler-table-wrap">
        <table className="traveler-table">
          <thead>
            <tr>
              <th>Operation</th>
              <th>Virtual tool</th>
              <th>Target ± tolerance</th>
              <th>Check</th>
            </tr>
          </thead>
          <tbody>
            {operations
              .filter((op) => !practice || op.station === "mill")
              .map((op) => (
                <tr key={op.id}>
                  <td>
                    <span className="table-station">
                      {op.station === "lathe" ? "01" : "02"}
                    </span>
                    {op.name}
                    {!op.required && <small>optional</small>}
                  </td>
                  <td>{tools.find((tool) => tool.id === op.tool)?.name}</td>
                  <td className="mono">
                    {op.target} ± {op.tolerance} {op.unit}
                  </td>
                  <td>
                    {inTolerance(op, state.results[op.id]) ? (
                      <span className="table-pass">
                        <Check size={14} /> Passed
                      </span>
                    ) : state.results[op.id] ? (
                      <span className="orange">Redo</span>
                    ) : (
                      <span className="faint">Pending</span>
                    )}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <div className="traveler-steps">
        <h3>
          <ClipboardList size={17} /> Your virtual setup
        </h3>
        <ol>
          <li>
            Choose a feature and its matching tool in the game’s tool rack.
          </li>
          <li>
            Adjust the feature’s game value to match the target, then start the
            virtual cycle.
          </li>
          <li>
            Inspect each result. Redo any feature that misses its tolerance.
          </li>
          <li>
            {practice
              ? "Finish the practice part to see your score."
              : "Transfer the shaped hub to the mill, add the bolt circle and flat, then inspect."}
          </li>
        </ol>
        <p className="small muted">
          Quality combines dimensions (45%), finish (20%), active cycle time
          (15%), tool choice (10%), and virtual interlock errors (10%). Optional
          features are scored only when attempted. Planning and pauses do not
          count toward cycle time.
        </p>
      </div>
      <Button
        tip="Close the traveler and return to the game"
        className="primary full"
        onClick={onClose}
      >
        Back to the floor
      </Button>
    </Modal>
  );
}
