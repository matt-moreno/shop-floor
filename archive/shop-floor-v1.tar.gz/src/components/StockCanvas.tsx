import { useEffect, useRef } from "react";
import { boltCircle, featureValue, latheProfile } from "../domain/geometry";
import type { GameState, Station } from "../domain/types";

export function StockCanvas({
  state,
  station,
  preview,
  coolant,
  compact = false,
}: {
  state: GameState;
  station: Station;
  preview: boolean;
  coolant: boolean;
  compact?: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const latest = useRef({ state, station, preview, coolant });
  latest.current = { state, station, preview, coolant };
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let frame = 0;
    let time = 0;
    let last = 0;
    const reduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    const resize = () => {
      const box = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = box.width * dpr;
      canvas.height = box.height * dpr;
    };
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    resize();
    function draw(now: number) {
      if (!ctx) return;
      const {
        state: s,
        station: machine,
        preview: ghost,
        coolant: wet,
      } = latest.current;
      const running = !!s.active && !s.paused;
      if (running && !reduced)
        time += Math.min((now - last) / 1000, 0.05) * (s.active!.spindle / 100);
      last = now;
      const w = 800,
        h = 490;
      ctx.setTransform(canvas.width / w, 0, 0, canvas.height / h, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const bg = ctx.createRadialGradient(400, 260, 10, 400, 260, 430);
      bg.addColorStop(0, "#27322f");
      bg.addColorStop(1, "#161c1c");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = "#34433e";
      ctx.lineWidth = 0.5;
      for (let x = 0; x < w; x += 32) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 32) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      ctx.strokeStyle = "#5e7565";
      ctx.setLineDash([6, 7]);
      ctx.beginPath();
      ctx.moveTo(40, 250);
      ctx.lineTo(760, 250);
      ctx.stroke();
      ctx.setLineDash([]);
      let toolX = 480,
        toolY = 145;
      const p = s.active?.progress ?? 0;
      if (machine === "lathe") {
        const ox = 200,
          oy = 250,
          scale = 6;
        ctx.fillStyle = "#0c1110";
        ctx.beginPath();
        ctx.ellipse(390, 407, 235, 17, 0, 0, Math.PI * 2);
        ctx.fill();
        const chuck = ctx.createLinearGradient(0, 90, 0, 410);
        chuck.addColorStop(0, "#84948b");
        chuck.addColorStop(0.3, "#45594d");
        chuck.addColorStop(0.5, "#a2afa4");
        chuck.addColorStop(0.8, "#3d5043");
        chuck.addColorStop(1, "#657569");
        ctx.fillStyle = "#202c26";
        ctx.fillRect(83, 104, 73, 292);
        ctx.fillStyle = chuck;
        ctx.fillRect(125, 112, 64, 276);
        ctx.beginPath();
        ctx.ellipse(190, 250, 23, 138, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#afbab0";
        ctx.lineWidth = 2;
        ctx.stroke();
        for (let i = 0; i < 3; i++) {
          const y = 250 + Math.sin(time * 9 + (i * Math.PI * 2) / 3) * 110;
          ctx.fillStyle = "#47584c";
          ctx.fillRect(174, y - 10, 35, 20);
          ctx.strokeStyle = "#8b9b8f";
          ctx.strokeRect(174, y - 10, 35, 20);
        }
        const profile = latheProfile(s);
        const release = s.results["lathe-part"]
          ? 16
          : s.active?.operationId === "lathe-part"
            ? p * 16
            : 0;
        const path = (target: boolean) => {
          const points = target ? latheProfile(s, true) : profile;
          ctx.beginPath();
          ctx.moveTo(ox + release, oy - points[0].radius * 3.1);
          for (const pt of points)
            ctx.lineTo(ox + pt.x * scale + release, oy - pt.radius * 3.1);
          for (const pt of [...points].reverse())
            ctx.lineTo(ox + pt.x * scale + release, oy + pt.radius * 3.1);
          ctx.closePath();
        };
        const metal = ctx.createLinearGradient(0, 125, 0, 375);
        metal.addColorStop(0, "#748b7e");
        metal.addColorStop(0.2, "#c4d0c2");
        metal.addColorStop(0.38, "#8fa597");
        metal.addColorStop(0.47, "#e1e6d9");
        metal.addColorStop(0.53, "#b8c8b7");
        metal.addColorStop(0.72, "#718b78");
        metal.addColorStop(1, "#344f3e");
        path(false);
        ctx.fillStyle = metal;
        ctx.fill();
        ctx.strokeStyle = "#b3c5b0";
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.save();
        path(false);
        ctx.clip();
        for (let i = 0; i < 90; i++) {
          ctx.strokeStyle = i % 4 === 0 ? "#e5edde20" : "#0b281a22";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(ox + i * 5 + release, 120);
          ctx.lineTo(ox + i * 5 + release, 380);
          ctx.stroke();
        }
        for (let i = 0; i < 6; i++) {
          const y = oy + Math.sin(time * 7 + (i * Math.PI) / 3) * 120;
          ctx.fillStyle = "#e6f4da0c";
          ctx.fillRect(ox, y, 440, 3);
        }
        const bore = featureValue(
          s,
          "lathe-bore",
          featureValue(s, "lathe-drill", 0),
        );
        if (bore > 0) {
          ctx.fillStyle = "#172820";
          ctx.fillRect(ox + 26, oy - bore * 1.5, 500, bore * 3);
          ctx.strokeStyle = "#9aaa94";
          ctx.strokeRect(ox + 26, oy - bore * 1.5, 500, bore * 3);
        }
        ctx.restore();
        if (ghost) {
          path(true);
          ctx.strokeStyle = "#f5ae76";
          ctx.lineWidth = 2;
          ctx.setLineDash([7, 5]);
          ctx.stroke();
          ctx.setLineDash([]);
        }
        const kind = s.active?.operationId.split("-")[1];
        toolX =
          kind === "drill" || kind === "bore"
            ? 690 - p * 160
            : kind === "face"
              ? 568
              : kind === "groove"
                ? 430
                : kind === "part"
                  ? 555
                  : 568 - p * 275;
        toolY =
          kind === "drill" || kind === "bore"
            ? 250
            : kind === "face"
              ? 120 + p * 200
              : 125 + (running || s.paused ? 30 : -25);
        ctx.save();
        ctx.translate(toolX, toolY);
        if (kind === "drill" || kind === "bore") {
          ctx.fillStyle = "#6f7e73";
          ctx.fillRect(0, -12, 95, 24);
          ctx.fillStyle = "#d8bb7c";
          ctx.beginPath();
          ctx.moveTo(0, -7);
          ctx.lineTo(-27, 0);
          ctx.lineTo(0, 7);
          ctx.fill();
        } else {
          ctx.fillStyle = "#37483c";
          ctx.fillRect(4, -84, 43, 64);
          ctx.strokeStyle = "#7a8d7c";
          ctx.strokeRect(4, -84, 43, 64);
          ctx.fillStyle = "#929c80";
          ctx.beginPath();
          ctx.moveTo(3, -30);
          ctx.lineTo(35, -10);
          ctx.lineTo(0, 6);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = "#ecc282";
          ctx.beginPath();
          ctx.moveTo(0, -10);
          ctx.lineTo(15, -2);
          ctx.lineTo(-4, 9);
          ctx.fill();
          ctx.fillStyle = "#435543";
          ctx.beginPath();
          ctx.arc(16, -16, 4, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        dimension(ctx, 210, 408, 568, 408, "60 gu · finished length");
        ctx.fillStyle = "#83968a";
        ctx.font = "11px monospace";
        ctx.fillText("CHUCK", 100, 435);
        ctx.fillText("Z →", 710, 270);
        ctx.fillText("X ↑", 690, 75);
      } else {
        const cx = 398,
          cy = 252;
        const rotation = (featureValue(s, "mill-index", 0) * Math.PI) / 180;
        ctx.save();
        ctx.translate(cx, cy);
        // Vise, backing billet, and optional indexed rotary faceplate.
        ctx.fillStyle = "#111915";
        ctx.fillRect(-208, -177, 416, 355);
        ctx.fillStyle = "#34483a";
        ctx.fillRect(-196, -170, 392, 340);
        for (let i = 0; i < 7; i++) {
          ctx.fillStyle = "#1b2b20";
          ctx.fillRect(-184 + i * 60, -163, 12, 326);
        }
        const jaw = ctx.createLinearGradient(0, -172, 0, -122);
        jaw.addColorStop(0, "#99ab99");
        jaw.addColorStop(0.3, "#5c725e");
        jaw.addColorStop(1, "#2d4833");
        ctx.fillStyle = jaw;
        ctx.fillRect(-205, -173, 410, 44);
        ctx.fillRect(-205, 136, 410, 35);
        ctx.strokeStyle = "#a4b19f";
        ctx.strokeRect(-205, -173, 410, 44);
        ctx.strokeRect(-205, 136, 410, 35);
        for (const x of [-175, 175])
          for (const y of [-151, 154]) {
            ctx.fillStyle = "#223d29";
            ctx.beginPath();
            ctx.arc(x, y, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#8c9f8a";
            ctx.stroke();
          }
        ctx.rotate(rotation);
        const metal = ctx.createRadialGradient(-50, -60, 5, 0, 0, 155);
        metal.addColorStop(0, "#dce3ce");
        metal.addColorStop(0.5, "#a3b69c");
        metal.addColorStop(1, "#718c72");
        ctx.fillStyle = metal;
        const billet = s.mode === "practice";
        const flat = featureValue(s, "mill-contour", 0) * 3.6;
        const stockPath = (inset = 0) => {
          ctx.beginPath();
          if (billet) {
            ctx.rect(
              -146 + inset,
              -126 + inset,
              292 - flat - inset * 2,
              252 - inset * 2,
            );
          } else {
            const radius = 145 - inset;
            const angle = Math.acos(Math.min(1, (radius - flat) / radius));
            ctx.arc(0, 0, radius, angle, Math.PI * 2 - angle);
            ctx.closePath();
          }
        };
        ctx.save();
        stockPath();
        ctx.clip();
        ctx.fillRect(-150, -150, 300, 300);
        for (let i = 0; i < 80; i++) {
          ctx.strokeStyle = i % 3 === 0 ? "#e6eed333" : "#3a5b3820";
          ctx.beginPath();
          if (billet) {
            ctx.moveTo(-150, -150 + i * 4);
            ctx.lineTo(150, -150 + i * 4);
          } else ctx.arc(0, 0, i * 2, 0, Math.PI * 2);
          ctx.stroke();
        }
        if (s.results["mill-face"] || s.active?.operationId === "mill-face") {
          ctx.fillStyle = "#e5eed626";
          ctx.fillRect(-150, -150, 300, 300);
        }
        ctx.restore();
        ctx.lineWidth = 2;
        ctx.strokeStyle = "#c6d2ba";
        stockPath();
        ctx.stroke();
        if (!billet) {
          ctx.fillStyle = "#14241a";
          ctx.beginPath();
          ctx.arc(
            0,
            0,
            featureValue(s, "lathe-bore", featureValue(s, "lathe-drill", 16)) *
              1.7,
            0,
            Math.PI * 2,
          );
          ctx.fill();
          ctx.strokeStyle = "#e1e7cf";
          ctx.stroke();
          ctx.strokeStyle = "#728b70";
          ctx.lineWidth = 8;
          ctx.beginPath();
          ctx.arc(0, 0, 96, 0, Math.PI * 2);
          ctx.stroke();
        }
        const width = featureValue(s, "mill-pocket", 0) * 3;
        if (width) {
          ctx.fillStyle = "#304d35";
          ctx.fillRect(-width / 2, -98, width, 90);
          ctx.strokeStyle = "#d1dbba";
          ctx.lineWidth = 1;
          ctx.strokeRect(-width / 2, -98, width, 90);
        }
        const drill = s.results["mill-drill"];
        const drilling = s.active?.operationId === "mill-drill";
        const points = boltCircle(
          drill?.value ?? (drilling ? s.active!.value : 56),
        );
        points.forEach((pt, i) => {
          const x = pt.x * 3.65,
            y = pt.y * 3.65;
          if (drill || (drilling && p * 6 > i)) {
            ctx.fillStyle = "#15261b";
            ctx.beginPath();
            ctx.arc(x, y, 13, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#d4debd";
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.strokeStyle = "#4d6e4d";
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(x, y + 2, 9, 0, Math.PI);
            ctx.stroke();
          } else if (ghost) {
            ctx.setLineDash([4, 4]);
            ctx.strokeStyle = "#f2b681";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(x, y, 13, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);
          }
        });
        if (s.results["mill-chamfer"]) {
          ctx.lineWidth = 5;
          ctx.strokeStyle = "#e0e9c9";
          stockPath(4);
          ctx.stroke();
        }
        if (ghost) {
          ctx.setLineDash([6, 5]);
          ctx.strokeStyle = "#f2b681";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(123, -78);
          ctx.lineTo(123, 78);
          ctx.stroke();
          ctx.setLineDash([]);
        }
        ctx.restore();
        const kind = s.active?.operationId.split("-")[1];
        if (kind === "drill") {
          const pt = points[Math.min(5, Math.floor(p * 6))];
          toolX =
            cx + (pt.x * Math.cos(rotation) - pt.y * Math.sin(rotation)) * 3.65;
          toolY =
            cy + (pt.x * Math.sin(rotation) + pt.y * Math.cos(rotation)) * 3.65;
        } else if (kind === "contour") {
          toolX =
            cx +
            Math.cos(rotation) * 123 -
            Math.sin(rotation) * (-80 + p * 160);
          toolY =
            cy +
            Math.sin(rotation) * 123 +
            Math.cos(rotation) * (-80 + p * 160);
        } else if (kind === "pocket") {
          toolX = cx - Math.sin(rotation) * (-95 + p * 85);
          toolY = cy + Math.cos(rotation) * (-95 + p * 85);
        } else {
          toolX = running && kind !== "index" ? cx - 110 + p * 220 : 626;
          toolY =
            running && kind !== "index"
              ? cy + Math.sin(p * Math.PI * 6) * 75
              : 99;
        }
        ctx.save();
        ctx.translate(toolX, toolY);
        ctx.fillStyle = "#122318aa";
        ctx.beginPath();
        ctx.arc(5, 8, 29, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#6b806b";
        ctx.beginPath();
        ctx.arc(0, 0, 25, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#b4c7a8";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.rotate(time * 10);
        ctx.fillStyle = "#cfcd99";
        ctx.fillRect(-17, -5, 34, 10);
        ctx.fillRect(-5, -17, 10, 34);
        ctx.fillStyle = "#334c34";
        ctx.beginPath();
        ctx.arc(0, 0, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
        dimension(ctx, 238, 444, 558, 444, "Ø 56 gu · bolt circle");
        ctx.fillStyle = "#83968a";
        ctx.font = "11px monospace";
        ctx.fillText("X →", 712, 270);
        ctx.fillText("Y ↑", 690, 75);
      }
      if (running && !reduced && s.active?.operationId !== "mill-index") {
        if (wet) {
          for (let i = 0; i < 22; i++) {
            const t = (time * 1.8 + i / 22) % 1;
            ctx.fillStyle = `rgba(136,201,194,${(1 - t) * 0.55})`;
            ctx.beginPath();
            ctx.ellipse(
              toolX - 60 + t * 90,
              toolY - 95 + t * 115,
              1.5,
              6,
              0.4,
              0,
              Math.PI * 2,
            );
            ctx.fill();
          }
        }
        for (let i = 0; i < 28; i++) {
          const t = (time * 1.6 + i / 28) % 1;
          const a = i * 2.399;
          ctx.strokeStyle = `rgba(227,195,132,${(1 - t) * 0.8})`;
          ctx.lineWidth = 2;
          const x = toolX + Math.cos(a) * t * 85,
            y = toolY + Math.sin(a) * t * 65 + t * t * 60;
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(x + Math.cos(a) * 5, y + 4);
          ctx.stroke();
        }
      }
      ctx.fillStyle = "#708577";
      ctx.font = "10px monospace";
      ctx.fillText(
        machine === "lathe"
          ? "SIDE PROFILE / ORTHOGRAPHIC"
          : "TOP VIEW / INDEXED FIXTURE",
        30,
        34,
      );
      ctx.fillText("SIMULATED GEOMETRY · GAME UNITS", 30, 469);
      frame = requestAnimationFrame(draw);
    }
    frame = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, []);
  return (
    <canvas
      ref={canvasRef}
      className={`stock-canvas ${compact ? "compact" : ""}`}
      role="img"
      aria-label={`${station === "lathe" ? "Animated side profile of the round stock and virtual cutting tool" : "Animated top view of the part in a vise, bolt holes, and milling tool"}. ${state.active ? `${Math.round(state.active.progress * 100)} percent cut complete.` : "Ready for the next operation."}`}
    />
  );
}
function dimension(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  label: string,
) {
  ctx.strokeStyle = "#6f8574";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.moveTo(x1, y1 - 5);
  ctx.lineTo(x1, y1 + 5);
  ctx.moveTo(x2, y2 - 5);
  ctx.lineTo(x2, y2 + 5);
  ctx.stroke();
  ctx.fillStyle = "#a5b79f";
  ctx.font = "11px monospace";
  ctx.textAlign = "center";
  ctx.fillText(label, (x1 + x2) / 2, y1 + 20);
  ctx.textAlign = "left";
}
