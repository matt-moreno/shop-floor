import { clamp } from "./game";
import type { GameState } from "./types";
export interface ProfilePoint {
  x: number;
  radius: number;
}
export function targetRadius(x: number, diameter = 48): number {
  return x < 18 ? 36 : x < 42 ? diameter / 2 : diameter / 2 - 5;
}
export function featureValue(
  state: GameState,
  id: string,
  fallback: number,
): number {
  if (state.active?.operationId === id)
    return fallback + (state.active.value - fallback) * state.active.progress;
  return state.results[id]?.value ?? fallback;
}
export function latheProfile(state: GameState, target = false): ProfilePoint[] {
  const length = target ? 60 : featureValue(state, "lathe-face", 64);
  const turn = state.results["lathe-turn"]
    ? 1
    : state.active?.operationId === "lathe-turn"
      ? state.active.progress
      : 0;
  const diameter =
    state.active?.operationId === "lathe-turn"
      ? state.active.value
      : (state.results["lathe-turn"]?.value ?? 48);
  const groove = target ? 0 : featureValue(state, "lathe-groove", 0);
  return Array.from({ length: 121 }, (_, i) => {
    const x = (i / 120) * length;
    let radius = target
      ? targetRadius(x)
      : 40 + (targetRadius(x, diameter) - 40) * turn;
    if (x >= 37 && x <= 40) radius -= groove;
    return { x, radius: clamp(radius, 0, 40) };
  });
}
export function boltCircle(diameter: number, count = 6, angle = 0) {
  return Array.from({ length: count }, (_, i) => {
    const theta = ((angle - 90) * Math.PI) / 180 + (i * Math.PI * 2) / count;
    return {
      x: (Math.cos(theta) * diameter) / 2,
      y: (Math.sin(theta) * diameter) / 2,
    };
  });
}
