import { hubJob, operations } from "../data/shop";
import type {
  CutResult,
  GameState,
  Inspection,
  Operation,
  Station,
} from "./types";

export const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));
export const initialGame = (mode: "job" | "practice" = "job"): GameState => ({
  version: 1,
  stage: mode === "practice" ? "mill" : "lathe",
  results: {},
  errors: 0,
  elapsed: 0,
  active: null,
  paused: false,
  message: "",
  mode,
});
export const inTolerance = (op: Operation, result?: CutResult) =>
  !!result && Math.abs(result.value - op.target) <= op.tolerance + 1e-8;
export const stageReady = (state: GameState, station: Station) =>
  operations
    .filter((op) => op.station === station && op.required)
    .every((op) => inTolerance(op, state.results[op.id]));
export const completedCount = (state: GameState, station?: Station) =>
  operations.filter(
    (op) =>
      op.required &&
      (!station || op.station === station) &&
      inTolerance(op, state.results[op.id]),
  ).length;
export const requiredCount = (station?: Station) =>
  operations.filter((op) => op.required && (!station || op.station === station))
    .length;
export const finishScore = (feed: number, spindle: number) =>
  Math.round(
    clamp(
      100 - Math.abs(feed - 90) * 0.35 - Math.abs(spindle - 100) * 0.18,
      45,
      100,
    ),
  );
export function validateCut(
  state: GameState,
  op: Operation,
  toolId: string,
  value: number,
): string | null {
  if (state.active)
    return "A virtual cycle is already running. Hold or reset it first.";
  if (state.stage !== op.station)
    return "This operation belongs to a different stage.";
  if (!Number.isFinite(value) || value < op.min || value > op.max)
    return "That game value is outside the editable range.";
  if (toolId !== op.tool)
    return "Tool mismatch. The virtual interlock stopped the cut. Choose the highlighted tool and try again.";
  if (state.results[op.id])
    return "Use Redo operation before cutting this feature again.";
  if (
    op.dependsOn.some(
      (id) =>
        !inTolerance(
          operations.find((item) => item.id === id)!,
          state.results[id],
        ),
    )
  )
    return "An earlier feature needs attention. Finish the preceding required operation within tolerance first.";
  return null;
}
export type GameAction =
  | {
      type: "start";
      operationId: string;
      toolId: string;
      value: number;
      feed: number;
      spindle: number;
    }
  | { type: "tick"; seconds: number }
  | { type: "hold" }
  | { type: "reset-cycle" }
  | { type: "redo"; operationId: string }
  | { type: "advance" }
  | { type: "reset" };
export function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case "reset":
      return initialGame(state.mode);
    case "start": {
      const op = operations.find((item) => item.id === action.operationId);
      if (!op) return state;
      const error = validateCut(state, op, action.toolId, action.value);
      if (error) return { ...state, errors: state.errors + 1, message: error };
      return {
        ...state,
        paused: false,
        message: "",
        active: {
          operationId: op.id,
          value: action.value,
          toolId: action.toolId,
          feed: clamp(action.feed, 50, 150),
          spindle: clamp(action.spindle, 50, 150),
          progress: 0,
        },
      };
    }
    case "tick": {
      if (
        !state.active ||
        state.paused ||
        !Number.isFinite(action.seconds) ||
        action.seconds <= 0
      )
        return state;
      const op = operations.find(
        (item) => item.id === state.active!.operationId,
      )!;
      const duration = (op.duration * 100) / state.active.feed;
      const seconds = Math.min(
        action.seconds,
        (1 - state.active.progress) * duration,
      );
      const progress = Math.min(1, state.active.progress + seconds / duration);
      if (progress < 1 - 1e-8)
        return {
          ...state,
          elapsed: state.elapsed + seconds,
          active: { ...state.active, progress },
        };
      const result: CutResult = {
        operationId: op.id,
        value: state.active.value,
        toolId: state.active.toolId,
        finish: finishScore(state.active.feed, state.active.spindle),
        seconds: duration,
      };
      return {
        ...state,
        elapsed: state.elapsed + seconds,
        active: null,
        results: { ...state.results, [op.id]: result },
        message: inTolerance(op, result)
          ? `${op.name} complete. Feature is within tolerance.`
          : `${op.name} is outside tolerance. Use Redo operation, move the value closer to ${op.target} ${op.unit}, and try again.`,
      };
    }
    case "hold":
      return state.active ? { ...state, paused: !state.paused } : state;
    case "reset-cycle":
      return {
        ...state,
        active: null,
        paused: false,
        message: "Cycle reset. The last completed geometry is restored.",
      };
    case "redo": {
      if (state.active) return state;
      // Descendant features are invalidated so the resulting part remains consistent.
      const invalid = new Set([action.operationId]);
      let changed = true;
      while (changed) {
        changed = false;
        for (const op of operations)
          if (
            !invalid.has(op.id) &&
            op.dependsOn.some((id) => invalid.has(id))
          ) {
            invalid.add(op.id);
            changed = true;
          }
      }
      return {
        ...state,
        results: Object.fromEntries(
          Object.entries(state.results).filter(([id]) => !invalid.has(id)),
        ),
        message:
          "Feature restored. Dependent features, if any, are ready to cut again.",
      };
    }
    case "advance": {
      if (
        state.active ||
        state.stage === "complete" ||
        !stageReady(state, state.stage)
      )
        return state;
      return {
        ...state,
        stage: state.stage === "lathe" ? "mill" : "complete",
        message: "",
      };
    }
  }
}
export function inspect(state: GameState): Inspection {
  const relevant = operations.filter(
    (op) => state.mode === "job" || op.station === "mill",
  );
  const scored = relevant.filter((op) => op.required || state.results[op.id]);
  const results = scored.map((op) => state.results[op.id]);
  const accuracy = Math.round(
    scored.reduce(
      (sum, op) =>
        sum +
        (state.results[op.id]
          ? clamp(
              100 -
                (Math.abs(state.results[op.id].value - op.target) /
                  op.tolerance) *
                  15,
              0,
              100,
            )
          : 0),
      0,
    ) / scored.length,
  );
  const finish = Math.round(
    results.reduce((sum, result) => sum + (result?.finish ?? 0), 0) /
      scored.length,
  );
  const idealTime = scored.reduce((sum, op) => sum + op.duration, 0);
  const time = Math.round(
    clamp(100 - Math.max(0, state.elapsed - idealTime * 1.2) * 2, 0, 100),
  );
  const tooling = Math.round(
    (100 *
      results.filter((result, i) => result?.toolId === scored[i].tool).length) /
      scored.length,
  );
  const safety = Math.max(0, 100 - state.errors * 12);
  const overall = Math.round(
    accuracy * 0.45 + finish * 0.2 + time * 0.15 + tooling * 0.1 + safety * 0.1,
  );
  return {
    accuracy,
    finish,
    time,
    tooling,
    safety,
    overall,
    grade:
      overall >= 95 ? "S" : overall >= 85 ? "A" : overall >= 70 ? "B" : "C",
    reward: Math.round((hubJob.reward * overall) / 100),
  };
}
export function restoreGame(
  raw: string | null,
  mode: "job" | "practice",
): GameState {
  if (!raw) return initialGame(mode);
  try {
    const data = JSON.parse(raw) as GameState;
    if (
      data.version !== 1 ||
      data.mode !== mode ||
      !["lathe", "mill", "complete"].includes(data.stage) ||
      (mode === "practice" && data.stage === "lathe") ||
      !data.results ||
      typeof data.results !== "object" ||
      !Number.isFinite(data.elapsed) ||
      data.elapsed < 0 ||
      !Number.isInteger(data.errors) ||
      data.errors < 0
    )
      return initialGame(mode);
    const results: Record<string, CutResult> = {};
    for (const op of operations) {
      const r = data.results[op.id];
      if (
        r &&
        r.operationId === op.id &&
        r.toolId === op.tool &&
        Number.isFinite(r.value) &&
        r.value >= op.min &&
        r.value <= op.max &&
        Number.isFinite(r.finish) &&
        r.finish >= 0 &&
        r.finish <= 100 &&
        Number.isFinite(r.seconds) &&
        r.seconds > 0
      )
        results[op.id] = r;
    }
    const state = {
      ...initialGame(mode),
      results,
      elapsed: data.elapsed,
      errors: data.errors,
      stage: data.stage,
    };
    if (
      mode === "job" &&
      state.stage !== "lathe" &&
      !stageReady(state, "lathe")
    )
      state.stage = "lathe";
    if (state.stage === "complete" && !stageReady(state, "mill"))
      state.stage = "mill";
    return state;
  } catch {
    return initialGame(mode);
  }
}
