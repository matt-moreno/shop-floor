export type Station = "lathe" | "mill";
export type OperationKind =
  | "face"
  | "turn"
  | "groove"
  | "drill"
  | "bore"
  | "part"
  | "pocket"
  | "contour"
  | "chamfer"
  | "index";
export interface Tool {
  id: string;
  number: string;
  name: string;
  kind: string;
  station: Station;
}
export interface Operation {
  id: string;
  station: Station;
  kind: OperationKind;
  name: string;
  description: string;
  tool: string;
  parameter: string;
  target: number;
  min: number;
  max: number;
  initial: number;
  tolerance: number;
  unit: string;
  required: boolean;
  dependsOn: string[];
  duration: number;
}
export interface Machine {
  id: Station;
  brand: string;
  name: string;
  type: string;
  axes: string;
  description: string;
  color: string;
}
export interface Stock {
  material: string;
  shape: "round" | "billet";
  diameter: number;
  length: number;
}
export interface Job {
  id: string;
  name: string;
  customer: string;
  reward: number;
  stock: Stock;
}
export interface CutResult {
  operationId: string;
  value: number;
  toolId: string;
  finish: number;
  seconds: number;
}
export interface ActiveCut {
  operationId: string;
  value: number;
  toolId: string;
  progress: number;
  feed: number;
  spindle: number;
}
export interface GameState {
  version: 1;
  stage: Station | "complete";
  results: Record<string, CutResult>;
  errors: number;
  elapsed: number;
  active: ActiveCut | null;
  paused: boolean;
  message: string;
  mode: "job" | "practice";
}
export interface Inspection {
  accuracy: number;
  finish: number;
  time: number;
  tooling: number;
  safety: number;
  overall: number;
  grade: string;
  reward: number;
}
