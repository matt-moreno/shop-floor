import { describe, expect, it } from "vitest";
import { operations } from "../data/shop";
import {
  gameReducer,
  initialGame,
  inspect,
  restoreGame,
  stageReady,
  validateCut,
} from "./game";
import { boltCircle, latheProfile } from "./geometry";
import type { GameState } from "./types";
function cut(state: GameState, id: string, offset = 0) {
  const op = operations.find((item) => item.id === id)!;
  return gameReducer(
    gameReducer(state, {
      type: "start",
      operationId: id,
      toolId: op.tool,
      value: op.target + offset,
      feed: 90,
      spindle: 100,
    }),
    { type: "tick", seconds: 100 },
  );
}
function finishStage(state: GameState) {
  return operations
    .filter((op) => op.station === state.stage && op.required)
    .reduce((next, op) => cut(next, op.id), state);
}
describe("fictional geometry", () => {
  it("starts as uniform round stock and produces the stepped target", () => {
    const blank = initialGame();
    expect(latheProfile(blank).every((point) => point.radius === 40)).toBe(
      true,
    );
    const finished = cut(cut(blank, "lathe-face"), "lathe-turn");
    expect(latheProfile(finished)).toEqual(latheProfile(finished, true));
    expect(
      new Set(latheProfile(finished).map((point) => point.radius)),
    ).toEqual(new Set([36, 24, 19]));
  });
  it("interpolates cutting geometry without modifying the completed stock", () => {
    let state = cut(initialGame(), "lathe-face");
    state = gameReducer(state, {
      type: "start",
      operationId: "lathe-turn",
      toolId: "turning",
      value: 48,
      feed: 100,
      spindle: 100,
    });
    state = gameReducer(state, { type: "tick", seconds: 2 });
    expect(latheProfile(state)[60].radius).toBe(32);
    expect(state.results["lathe-turn"]).toBeUndefined();
    expect(
      latheProfile(gameReducer(state, { type: "reset-cycle" }))[60].radius,
    ).toBe(40);
  });
  it("places six holes at equal radii and rotates the pattern", () => {
    const points = boltCircle(56);
    expect(points).toHaveLength(6);
    points.forEach((point) =>
      expect(Math.hypot(point.x, point.y)).toBeCloseTo(28),
    );
    expect(boltCircle(56, 6, 90)[0].x).toBeCloseTo(28);
  });
});
describe("job progression and recovery", () => {
  it("blocks wrong tools, invalid parameters, and out-of-sequence cuts", () => {
    const state = initialGame();
    expect(validateCut(state, operations[0], "center", 60)).toContain(
      "Tool mismatch",
    );
    expect(validateCut(state, operations[0], "turning", NaN)).toContain(
      "outside",
    );
    expect(validateCut(state, operations[1], "turning", 48)).toContain(
      "earlier",
    );
    expect(gameReducer(state, { type: "advance" }).stage).toBe("lathe");
  });
  it("pauses time and progress, then resumes", () => {
    let state = gameReducer(initialGame(), {
      type: "start",
      operationId: "lathe-face",
      toolId: "turning",
      value: 60,
      feed: 100,
      spindle: 100,
    });
    state = gameReducer(state, { type: "hold" });
    expect(gameReducer(state, { type: "tick", seconds: 2 })).toEqual(state);
    state = gameReducer(state, { type: "hold" });
    expect(
      gameReducer(state, { type: "tick", seconds: 1 }).active?.progress,
    ).toBeGreaterThan(0);
  });
  it("requires dimensional quality and invalidates dependent cuts on redo", () => {
    let state = cut(initialGame(), "lathe-face", 2);
    expect(stageReady(state, "lathe")).toBe(false);
    state = gameReducer(state, { type: "redo", operationId: "lathe-face" });
    state = finishStage(state);
    expect(stageReady(state, "lathe")).toBe(true);
    state = gameReducer(state, { type: "redo", operationId: "lathe-turn" });
    expect(Object.keys(state.results)).toEqual(["lathe-face"]);
  });
  it("completes both stages with perfect scores and replays cleanly", () => {
    let state = finishStage(initialGame());
    state = gameReducer(state, { type: "advance" });
    expect(state.stage).toBe("mill");
    state = finishStage(state);
    state = gameReducer(state, { type: "advance" });
    expect(state.stage).toBe("complete");
    expect(inspect(state)).toMatchObject({
      overall: 100,
      grade: "S",
      reward: 850,
    });
    expect(gameReducer(state, { type: "reset" })).toEqual(initialGame());
  });
  it("penalizes errors and repeat cycle time without making recovery impossible", () => {
    const state = finishStage(initialGame());
    expect(inspect({ ...state, errors: 3, elapsed: 90 }).overall).toBeLessThan(
      inspect(state).overall,
    );
  });
  it("protects against broken saves and never resumes unattended cuts", () => {
    expect(restoreGame("{broken", "job")).toEqual(initialGame());
    expect(
      restoreGame(
        JSON.stringify({ ...initialGame(), stage: "complete" }),
        "job",
      ).stage,
    ).toBe("lathe");
    const active = gameReducer(initialGame(), {
      type: "start",
      operationId: "lathe-face",
      toolId: "turning",
      value: 60,
      feed: 100,
      spindle: 100,
    });
    expect(restoreGame(JSON.stringify(active), "job").active).toBeNull();
  });
});

describe("stage and practice boundaries", () => {
  it("cannot transfer a ready part during an optional cut", () => {
    let state = finishStage(initialGame());
    state = gameReducer(state, {
      type: "start",
      operationId: "lathe-groove",
      toolId: "grooving",
      value: 3,
      feed: 90,
      spindle: 100,
    });
    expect(state.active).not.toBeNull();
    expect(gameReducer(state, { type: "advance" }).stage).toBe("lathe");
    expect(
      gameReducer(gameReducer(state, { type: "reset-cycle" }), {
        type: "advance",
      }).stage,
    ).toBe("mill");
  });

  it("scores and replays practice without requiring lathe features", () => {
    let state = finishStage(initialGame("practice"));
    state = gameReducer(state, { type: "advance" });
    expect(state.stage).toBe("complete");
    expect(inspect(state).overall).toBe(100);
    expect(
      Object.keys(state.results).every((id) => id.startsWith("mill-")),
    ).toBe(true);
    expect(gameReducer(state, { type: "reset" })).toEqual(
      initialGame("practice"),
    );
    expect(restoreGame(JSON.stringify(state), "job")).toEqual(initialGame());
  });
});
