# Shop Floor

A fictional CNC shop game. Entertainment and education only: no machine connections, G-code, CAM, or real operating instructions. All measurements are invented **game units (gu)**, and controls affect only the simulation.

## Implementation plan

1. Create a React + TypeScript + Vite app with original procedural visuals and a responsive shop dashboard.
2. Model machines, jobs, stock, tools, deterministic cuts, inspections, and scoring independently of the UI.
3. Build a replayable Aluminum Wheel Hub job: a side-profile lathe stage followed by a top-view mill stage.
4. Add guided onboarding, tool selection, virtual overrides, preview, recoverable errors, inspection, and a billet practice mode.
5. Verify domain rules with unit tests, format, type-check, build, and smoke-test the browser experience.

## Run

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. `npm run build` creates `dist`; `npm run preview` serves that production build.

## Checks

```sh
npm run format:check
npm run typecheck
npm test
npm run build
```

## Structure

- `src/domain/`: pure geometry, inspection, scoring, and game state rules.
- `src/data/`: fictional machine, tool, operation, and job configurations.
- `src/components/`: reusable UI, Canvas stock rendering, and original SVG machine illustrations.
- `src/hooks/`: simulation clock, optional synthesized audio, and local save handling.
- `src/assets/`: asset replacement notes; initial visuals are entirely procedural.

The job and current selections save locally between visits. Cycle Start commits one selected operation; Feed Hold pauses its simulation clock. Reset cancels the in-flight cut. Redo restores the selected operation, allowing a fresh attempt. A new shift clears the current job. The mill also offers an independent rectangular-billet practice session.

## Design boundaries

Geometry is deterministic and deliberately simplified. Parameters are fictional game values; feed/spindle overrides affect animation time and a game-style finish score only. Graphics preview displays a ghost target without changing stock. There is no network integration or machine communication. Optional future work: additional jobs, richer sound design, more stock materials, and licensed replacement assets.

## Gameplay

The first job has seven required features and five optional details. Match each feature's target using the slider, select the matching tool, then use **Cycle Start**. The orange dot in the tool rack marks the appropriate tool. All required features must pass their displayed tolerance before **Transfer to mill** or **Finish & inspect** becomes available.

- Dimensions: 45% of the score. Deviations from the target reduce the result.
- Finish: 20%. The game's smoothest finish is at 90% feed and 100% spindle.
- Cycle efficiency: 15%. Only time spent cutting counts; retries consume time.
- Tool choice: 10%. Accepted features retain the tool that made them.
- Error-free work: 10%. Virtual interlock errors reduce this score.

A redo removes the selected feature and any dependent features. Optional features affect inspection only when attempted. Audio is opt-in. Reduced-motion preferences suppress continuous spinning and particles. Leaving the station or hiding the browser holds an active cycle; reload restores completed features and discards an unfinished cut.

## Validation

The implementation includes domain tests for target profiles, cut interpolation, bolt-circle geometry, tool validation, prerequisite enforcement, tolerance failures, dependency-aware redo, pause/resume, stage boundaries, practice isolation, score calculation, replay, and saved-state recovery. Browser verification covered all twelve operations through final inspection, incorrect tools, dimensional recovery, cycle reset, held-cycle navigation, local persistence, and responsive tablet/phone layouts.
